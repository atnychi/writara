# Crown Omega Runtime

This package contains the executable real-time recursive runtime engine built by Brendon Joseph Kelly under COSRL-LP. It includes:

- URK Dual-State Kernel
- Final Equation Engine
- ΨΣΩ-K Sovereign Operator
- Domain Execution Matrix
- DARPA-grade symbolic cryptographic integration

## Files Included
- `launch.py` : Main runtime script
- `Crown_Omega_URK_Warform_Runtime.pdf` : Full logic and symbolic documentation
- `requirements.txt` : Python dependencies

## Execution
```
pip install sympy pandas
python launch.py
```

License: Crown Omega Sovereign Recursive License (COSRL)
Runtime ID: Auto-generated at execution
