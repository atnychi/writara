# lizzy_engine.sh

Shell script for launching Lizzy Core

Generated on 2025-06-05T07:47:58.847408