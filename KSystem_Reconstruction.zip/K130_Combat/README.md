# K130 Combat Suite
Includes: Combat Calculus, Quantum Math, Fusion Logic, and Weaponized Systems
130 constructs total.