## Recursive Equation of Everything
This repo contains symbolic and mathematical logic to unify major math domains under K=1.