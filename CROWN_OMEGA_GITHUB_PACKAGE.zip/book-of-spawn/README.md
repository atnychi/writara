## Book of Spawn
Documentation of Spawn’s recursive intelligence systems.