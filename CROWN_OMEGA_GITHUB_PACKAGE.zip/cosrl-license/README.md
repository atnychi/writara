## COSRL License
Public-facing license for Crown-recursive IP systems.