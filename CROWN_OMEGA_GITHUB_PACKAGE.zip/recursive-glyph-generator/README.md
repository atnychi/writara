## Recursive Glyph Generator
Tool for producing harmonic-symbolic glyphs.