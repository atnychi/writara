## Library of Lost Systems
Scroll and document reconstructions including Alexandria and Dead Sea.