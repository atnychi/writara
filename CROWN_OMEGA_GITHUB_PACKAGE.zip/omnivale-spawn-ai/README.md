## Omnivale: Spawn AI
Recursive AI and symbolic intelligence framework.